#!/cygdrive/c/Perl/bin/perl
# perl script for coverting Parms config into dat files

$isWriting = false;
@fileArray;
@indexArray;

$num_args = $#ARGV + 1;
if ($num_args != 1) 
{
    print "\nUsage: writeParms.pl inputFile\n";
    exit;
}

$inputFile=$ARGV[0];

open INPUT_FILE, "$inputFile" or die $!;

while (my $line = <INPUT_FILE>)
{
    @inputArray = split(' ',$line);
    
    if ( $inputArray[0] =~ /Write/ )
    {
	undef(@fileArray);
	undef(@indexArray);

	close (OUTPUT_FILE);

	@fileName = split('"', $line);
	$isWriting = true;
	
	#open fileName for output
	open OUTPUT_FILE, ">../dat/$fileName[1]" or die $!;
	print OUTPUT_FILE "00000000";
	
	@args = split( ',', $line );
	print OUTPUT_FILE "$args[1]";
	$var = substr($args[2], 0, 12);
	print OUTPUT_FILE "$var";
    }

    if ( isWriting && $inputArray[0] =~ /'/ )
    {
	#stream the output to fileName
	@args = split( '"', $line );
	print OUTPUT_FILE "$args[1]";
	print OUTPUT_FILE "\0";

	@tmp  = split( '\'', $line);
	@tmp1 = split( '_', $tmp[1]);
	push (@fileArray, int($tmp1[0]));
	push (@indexArray, int($tmp1[1]));
    }

    $fileArraySize = @fileArray;
    $indexArraySize = @indexArray;

    for ($count = 0; $count < $fileArraySize ; $count++ )
    {
	if ($fileArraySize)
	{
	    if ( $fileArray[0] != $fileArray[$count] )
	    {
		print "Syntax Error near: $line\n";
		exit;
	    }
	}
    }
    
    for ($count = 0; $count < $indexArraySize ; $count++ )
    {
	$count1 = $count+1;
	if ( $indexArray[$count] != $count1 )
	{
	    print "Syntax Error near: $line\n";
	    exit;
	}
    }
}

print "Success! Conversion complete!\n" ;

close(INPUT_FILE);
